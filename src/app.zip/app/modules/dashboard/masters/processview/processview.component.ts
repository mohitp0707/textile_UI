import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-processview',
  templateUrl: './processview.component.html',
  styleUrls: ['./processview.component.scss']
})
export class ProcessviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
