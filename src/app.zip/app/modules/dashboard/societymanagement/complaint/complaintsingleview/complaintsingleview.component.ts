import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complaintsingleview',
  templateUrl: './complaintsingleview.component.html',
  styleUrls: ['./complaintsingleview.component.scss']
})
export class ComplaintsingleviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
