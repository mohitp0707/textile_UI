import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-documentsingleview',
  templateUrl: './documentsingleview.component.html',
  styleUrls: ['./documentsingleview.component.scss']
})
export class DocumentsingleviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
