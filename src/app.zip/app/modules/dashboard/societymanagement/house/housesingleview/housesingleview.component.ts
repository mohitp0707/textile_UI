import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-housesingleview',
  templateUrl: './housesingleview.component.html',
  styleUrls: ['./housesingleview.component.scss']
})
export class HousesingleviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
