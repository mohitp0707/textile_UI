import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewreceipt',
  templateUrl: './viewreceipt.component.html',
  styleUrls: ['./viewreceipt.component.scss']
})
export class ViewreceiptComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
