import { Component, OnInit } from '@angular/core';
import { AdduserComponent } from '../../../manageuser/adduser/adduser.component';
@Component({
  selector: 'app-party',
  templateUrl: './party.component.html',
  styleUrls: ['./party.component.scss']
})
export class PartyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
