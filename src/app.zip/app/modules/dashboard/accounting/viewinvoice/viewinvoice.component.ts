import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { DataServiceService } from '../../../../provider/data-service.service';

@Component({
  selector: 'app-viewinvoice',
  templateUrl: './viewinvoice.component.html',
  styleUrls: ['./viewinvoice.component.scss']
})
export class ViewinvoiceComponent implements OnInit {

	invoiceList : any = [];
	p: number = 1;
	searchText:any;
	constructor(public ds : DataServiceService, public route : ActivatedRoute){
		this.getData();
	}
	
	
		getData(){
		this.ds.getData('/Purchase_Retrieve').then((data:any) => {
			this.invoiceList = data.recordset || [];
		},err => {
			console.log(err);
		})
		
		
		
	}
	deletedata(id, index){
		console.log(id);
		this.ds.deleteData('/deletePurchaseInv', id).then((data) => {
			if(data){
				this.invoiceList.splice(index, 1);
				alert("deleted Sucessfully");
			}
		}, err => {
			console.log("Fail");
		})
	}	
	
	ngOnInit() {
	}

	
}