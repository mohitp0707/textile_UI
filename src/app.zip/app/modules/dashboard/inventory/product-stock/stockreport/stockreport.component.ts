import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stockreport',
  templateUrl: './stockreport.component.html',
  styleUrls: ['./stockreport.component.scss']
})
export class StockreportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
