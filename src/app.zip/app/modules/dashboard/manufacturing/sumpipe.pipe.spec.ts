import { SumpipePipe } from './sumpipe.pipe';

describe('SumpipePipe', () => {
  it('create an instance', () => {
    const pipe = new SumpipePipe();
    expect(pipe).toBeTruthy();
  });
});
