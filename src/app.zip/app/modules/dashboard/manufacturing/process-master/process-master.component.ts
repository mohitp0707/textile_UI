import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-process-master',
  templateUrl: './process-master.component.html',
  styleUrls: ['./process-master.component.scss']
})
export class ProcessMasterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
