import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usersingleview',
  templateUrl: './usersingleview.component.html',
  styleUrls: ['./usersingleview.component.scss']
})
export class UsersingleviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
